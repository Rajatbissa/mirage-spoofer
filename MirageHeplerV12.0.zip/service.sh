#!/system/bin/sh
# MIRAGE v12.0 - FINAL DUAL STORAGE LOGIC

# 1. Boot Wait
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 1; done

CMD_FILE="/data/local/tmp/mirage.cmd"
STATUS_FILE="/data/local/tmp/mirage_status"

# --- Path Logic ---
# Internal: Profiles yahan se switch hongi (Super Fast)
INTERNAL_DIR="/data/data/com.mirage.spoofer/profiles"
# External: SD Card par Folder B (Full Session Vault)
EXTERNAL_DIR="/sdcard/MirageBackups/Full_Session_Backups"
LOG_FILE="/sdcard/MirageBackups/mirage_debug.log"

mkdir -p "$INTERNAL_DIR"
mkdir -p "$EXTERNAL_DIR"

log_trace() { echo "[$(date '+%H:%M:%S')] $1" >> "$LOG_FILE"; }

get_uid() {
  cat /data/system/packages.list | grep "^$1 " | awk '{print $2}'
}

send_receipt() {
  echo "DONE" > "$STATUS_FILE"
  chmod 666 "$STATUS_FILE"
}

log_trace "🚀 Mirage Service v12.0 Started"

while true; do
  if [ -f "$CMD_FILE" ]; then
    CMD=$(cat "$CMD_FILE")
    rm -f "$CMD_FILE"
    rm -f "$STATUS_FILE"
    
    set -- $CMD
    ACTION="$1"     # BACKUP, RESTORE, EXPORT_SESSION, IMPORT_SESSION, WIPE
    PKG="$2"        
    REL_PATH="$3"   

    # Path Setup
    SWAP_PATH="$INTERNAL_DIR/$REL_PATH"
    VAULT_PATH="$EXTERNAL_DIR/$REL_PATH"
    
    mkdir -p "$SWAP_PATH"
    
    DATA_MAIN="/data/user/0/$PKG"
    DATA_DE="/data/user_de/0/$PKG"
    TAR_MAIN="$SWAP_PATH/${PKG}_main.tar"
    TAR_DE="$SWAP_PATH/${PKG}_de.tar"

    # ==========================
    # 📦 EXPORT_SESSION (Internal to Folder B)
    # ==========================
    if [ "$ACTION" = "EXPORT_SESSION" ]; then
        log_trace "Exporting $REL_PATH to Folder B..."
        mkdir -p "$VAULT_PATH"
        cp -rf "$SWAP_PATH"/. "$VAULT_PATH/" 2>/dev/null
    fi

    # ==========================
    # 📥 IMPORT_SESSION (Folder B to Internal)
    # ==========================
    if [ "$ACTION" = "IMPORT_SESSION" ]; then
        log_trace "Importing $REL_PATH from Folder B..."
        mkdir -p "$SWAP_PATH"
        cp -rf "$VAULT_PATH"/. "$SWAP_PATH/" 2>/dev/null
        ACTION="RESTORE" # Copy ke baad turant inject karega
    fi

    # ==========================
    # 💾 BACKUP (To Internal)
    # ==========================
    if [ "$ACTION" = "BACKUP" ]; then
        am force-stop "$PKG"
        [ -d "$DATA_MAIN" ] && tar -cf "$TAR_MAIN" -C "$DATA_MAIN" .
        [ -d "$DATA_DE" ] && tar -cf "$TAR_DE" -C "$DATA_DE" .
        chmod -R 666 "$SWAP_PATH"
    fi

    # ==========================
    # ♻️ RESTORE (From Internal)
    # ==========================
    if [ "$ACTION" = "RESTORE" ]; then
        am force-stop "$PKG"
        APP_UID=$(get_uid "$PKG")
        if [ ! -z "$APP_UID" ]; then
            if [ -f "$TAR_MAIN" ]; then
                rm -rf "$DATA_MAIN"/*
                tar -xf "$TAR_MAIN" -C "$DATA_MAIN"
            fi
            if [ -f "$TAR_DE" ]; then
                rm -rf "$DATA_DE"/*
                tar -xf "$TAR_DE" -C "$DATA_DE"
            fi
            chown -R "$APP_UID":"$APP_UID" "$DATA_MAIN" "$DATA_DE"
            chmod -R 775 "$DATA_MAIN" "$DATA_DE"
            restorecon -R "$DATA_MAIN" "$DATA_DE"
        fi
    fi

    # ==========================
    # 🧹 WIPE
    # ==========================
    if [ "$ACTION" = "WIPE" ]; then
      am force-stop "$PKG"
      pm clear "$PKG"
    fi
	
	# ==========================
    # 🛡️ PROXY START (Targeted)
    # ==========================
    if [ "$ACTION" = "PROXY_ON" ]; then
        HOST="$PKG"  # Command format: PROXY_ON [Host:Port] [TargetPkg]
        PORT="$3"
        TARGET_APP="$4"
        
        APP_UID=$(get_uid "$TARGET_APP")
        
        if [ ! -z "$APP_UID" ]; then
            log_trace "Starting Proxy for UID: $APP_UID ($TARGET_APP) on $HOST:$PORT"
            
            # 1. Purane rules saaf karein
            iptables -t nat -F
            
            # 2. Targeted Redirection (TCP Traffic)
            # HTTP (80) aur HTTPS (443) ko proxy IP:PORT par bhej rahe hain
            iptables -t nat -A OUTPUT -p tcp -m owner --uid-owner "$APP_UID" --dport 80 -j DNAT --to-destination "$HOST:$PORT"
            iptables -t nat -A OUTPUT -p tcp -m owner --uid-owner "$APP_UID" --dport 443 -j DNAT --to-destination "$HOST:$PORT"
            
            # 3. DNS Leak Protection (Optional)
            iptables -t nat -A OUTPUT -p udp -m owner --uid-owner "$APP_UID" --dport 53 -j DNAT --to-destination "8.8.8.8:53"
            
            log_trace "Proxy Rules Applied Successfully"
        fi
    fi

    # ==========================
    # 🚫 PROXY OFF
    # ==========================
    if [ "$ACTION" = "PROXY_OFF" ]; then
        log_trace "Cleaning up Proxy Rules..."
        iptables -t nat -F
        log_trace "Proxy Disabled"
    fi

    send_receipt
  fi
  sleep 1
done