#!/system/bin/sh
# MIRAGE v2.0 - UBER NUCLEAR STABILITY (Handshake Mode)

# 1. Boot Wait
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 1; done

CMD_FILE="/data/local/tmp/mirage.cmd"
STATUS_FILE="/data/local/tmp/mirage_status"
BASE_DIR="/data/media/0/MirageBackups"
LOG_FILE="/sdcard/MirageBackups/mirage_debug.log"
mkdir -p "$BASE_DIR"

log_trace() { echo "[$(date '+%H:%M:%S')] $1" >> "$LOG_FILE"; }

get_uid() {
  cat /data/system/packages.list | grep "^$1 " | awk '{print $2}'
}

send_receipt() {
  echo "DONE" > "$STATUS_FILE"
  chmod 666 "$STATUS_FILE"
  log_trace "✅ Receipt Sent: Task Done"
}

log_trace "🚀 Mirage Service v10 Started"

while true; do
  if [ -f "$CMD_FILE" ]; then
    CMD=$(cat "$CMD_FILE")
    rm -f "$CMD_FILE"
    rm -f "$STATUS_FILE"
    
    set -- $CMD
    ACTION="$1"
    PKG="$2"
    REL_PATH="$3"
    
   # ✅ Naya aur Final Logic:
FULL_PATH="$BASE_DIR/$REL_PATH"
mkdir -p "$FULL_PATH"

DATA_MAIN="/data/user/0/$PKG"
DATA_DE="/data/user_de/0/$PKG"
DATA_EXT="/sdcard/Android/data/$PKG"

# Package name ke sath file banegi (Uber ka alag, Telegram ka alag)
TAR_MAIN="$FULL_PATH/${PKG}_main.tar"
TAR_DE="$FULL_PATH/${PKG}_de.tar"
    
    log_trace "🤖 Running $ACTION for $PKG"

    # ==========================
    # 💾 BACKUP (Main + DE)
    # ==========================
    if [ "$ACTION" = "BACKUP" ]; then
        mkdir -p "$FULL_PATH"
        sync
        [ -d "$DATA_MAIN" ] && tar -cf "$TAR_MAIN" -C "$DATA_MAIN" .
        [ -d "$DATA_DE" ] && tar -cf "$TAR_DE" -C "$DATA_DE" .
        chmod 666 "$TAR_MAIN" "$TAR_DE" 2>/dev/null
    fi

    # ==========================
    # 🧹 WIPE (Strict Clean)
    # ==========================
    if [ "$ACTION" = "WIPE" ]; then
      am force-stop "$PKG"
      [ -d "$DATA_MAIN" ] && rm -rf "$DATA_MAIN"/* "$DATA_MAIN"/.* 2>/dev/null
      [ -d "$DATA_DE" ] && rm -rf "$DATA_DE"/* "$DATA_DE"/.* 2>/dev/null
      rm -rf "$DATA_EXT"
      # Extra measure for Uber
      pm clear "$PKG"
    fi

    # ==========================
    # ♻️ RESTORE (Uber & Heavy Apps Fix)
    # ==========================
    if [ "$ACTION" = "RESTORE" ]; then
        am force-stop "$PKG"
        APP_UID=$(get_uid "$PKG")
        
        if [ ! -z "$APP_UID" ]; then
            # 1. Main Data
            if [ -f "$TAR_MAIN" ]; then
                rm -rf "$DATA_MAIN"/*
                tar -xf "$TAR_MAIN" -C "$DATA_MAIN"
                sync
                chown -R "$APP_UID":"$APP_UID" "$DATA_MAIN"
                chmod -R 775 "$DATA_MAIN"
                restorecon -R "$DATA_MAIN"
            fi
            
            # 2. DE Data (Crucial for Login)
            if [ -f "$TAR_DE" ]; then
                rm -rf "$DATA_DE"/*
                tar -xf "$TAR_DE" -C "$DATA_DE"
                sync
                chown -R "$APP_UID":"$APP_UID" "$DATA_DE"
                chmod -R 775 "$DATA_DE"
                restorecon -R "$DATA_DE"
            fi
        fi
    fi
    
    send_receipt
  fi
  sleep 0.1
done